import { defineConfig } from 'vite'
import path from 'path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'

function figmaAssetResolver() {
  return {
    name: 'figma-asset-resolver',
    resolveId(id) {
      if (id.startsWith('figma:asset/')) {
        const filename = id.replace('figma:asset/', '')
        return path.resolve(__dirname, 'src/assets', filename)
      }
    },
  }
}

export default defineConfig({
  // ВАЖНО: замени 'ИМЯ-РЕПОЗИТОРИЯ' на реальное название твоего репозитория на GitHub
  // Например, если репозиторий называется "auto-service", напиши: base: '/auto-service/'
  // Если используешь кастомный домен или это username.github.io — оставь base: '/'
  base: '/ИМЯ-РЕПОЗИТОРИЯ/',

  plugins: [
    figmaAssetResolver(),
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  assetsInclude: ['**/*.svg', '**/*.csv'],
})
